package me.yourname.crystalcompass;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.inventory.PrepareItemCraftEvent;

import java.util.Arrays;

public class Main extends JavaPlugin implements Listener {
    
    private final NamespacedKey itemKey = new NamespacedKey(this, "custom_item");

    @Override
    public void onEnable() {
        getLogger().info("§dCrystalCompass loaded! 🧭");
        getServer().getPluginManager().registerEvents(this, this);
        registerFragmentRecipe();
        registerCompassRecipe();
    }

    // ==============================================
    //  ✨ Crystal Compass Fragment — with Glint!
    // ==============================================
    private ItemStack createFragment() {
        ItemStack fragment = new ItemStack(Material.ECHO_SHARD);
        ItemMeta meta = fragment.getItemMeta();
        
        meta.setDisplayName("§d§lCrystal Compass Fragment");
        meta.setLore(Arrays.asList(
            "§7A shard resonating with ancient music",
            "§7and star-metal energy...",
            "",
            "§dCombine 9 to forge the legendary Compass!"
        ));
        
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "compass_fragment");
        meta.setCustomModelData(4);
        meta.setEnchantmentGlintOverride(true); // ✨ Always glows!
        
        fragment.setItemMeta(meta);
        return fragment;
    }

    // ==============================================
    //  🧭 Crystal Compass — with Glint!
    // ==============================================
    private ItemStack createCompass() {
        ItemStack compass = new ItemStack(Material.RECOVERY_COMPASS);
        ItemMeta meta = compass.getItemMeta();
        
        meta.setDisplayName("§d§lCrystal Compass");
        meta.setLore(Arrays.asList(
            "§7Points toward the nearest geode anywhere you go.",
            "§7Forged from ancient music and star-metal.",
            "",
            "§dThis is a legendary artifact."
        ));
        
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, "crystal_compass");
        meta.setCustomModelData(4);
        meta.setEnchantmentGlintOverride(true); // ✨ Always glows!
        
        compass.setItemMeta(meta);
        return compass;
    }

    // ==============================================
    //  Step 1: 8 Netherite Blocks + Disc:5 → Fragment
    // ==============================================
    private void registerFragmentRecipe() {
        ItemStack result = createFragment();
        NamespacedKey key = new NamespacedKey("crystalcompass", "compass_fragment");
        ShapedRecipe recipe = new ShapedRecipe(key, result);
        
        recipe.shape("NNN", "NDN", "NNN");
        recipe.setIngredient('N', Material.NETHERITE_BLOCK);
        recipe.setIngredient('D', Material.MUSIC_DISC_5);
        
        Bukkit.addRecipe(recipe);
    }

    // ==============================================
    //  Step 2: 9 Fragments → Compass
    // ==============================================
    @EventHandler
    public void onCraft(PrepareItemCraftEvent event) {
        ItemStack result = event.getRecipe().getResult();
        if (result == null || result.getItemMeta() == null) return;
        
        String resultType = result.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
        if (!"crystal_compass".equals(resultType)) return;
        
        for (ItemStack item : event.getInventory().getMatrix()) {
            if (item == null || item.getType() != Material.ECHO_SHARD) {
                event.getInventory().setResult(null);
                return;
            }
            String itemType = item.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
            if (!"compass_fragment".equals(itemType)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    private void registerCompassRecipe() {
        ItemStack result = createCompass();
        NamespacedKey key = new NamespacedKey("crystalcompass", "crystal_compass");
        ShapedRecipe recipe = new ShapedRecipe(key, result);
        
        recipe.shape("FFF", "FFF", "FFF");
        recipe.setIngredient('F', Material.ECHO_SHARD);
        
        Bukkit.addRecipe(recipe);
    }

    @Override
    public void onDisable() {
        getLogger().info("CrystalCompass disabled.");
    }
}
